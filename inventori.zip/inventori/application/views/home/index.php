<div class="row">
  <div class="col-sm-12 mt-3">
    <div class="card mb-3">
      <div class="card-header">
        Total User
      </div>
      <div class="card-body text-center">
        5
      </div>
    </div>
    <div class="card mb-3">
      <div class="card-header">
        Total Category
      </div>
      <div class="card-body text-center">
        12
      </div>
    </div>
    <div class="card mb-3">
      <div class="card-header">
        Total Brand
      </div>
      <div class="card-body text-center">
        3
      </div>
    </div>
    <div class="card mb-3">
      <div class="card-header">
        Total Item in Stock
      </div>
      <div class="card-body text-center">
        89
      </div>
    </div>
  </div>
</div>